import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/app_models.dart';
import '../state/app_state.dart';
import 'notifications_screen.dart';

class ScheduleTab extends StatefulWidget {
  const ScheduleTab({super.key});

  @override
  State<ScheduleTab> createState() => _ScheduleTabState();
}

class _ScheduleTabState extends State<ScheduleTab>
    with SingleTickerProviderStateMixin {
  late DateTime _selectedDate;
  late DateTime _weekStart;
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  bool _isMonthView = false;

  @override
  void initState() {
    super.initState();
    _selectedDate = DateTime.now();
    _weekStart = _getWeekStart(_selectedDate);
    _animController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnim =
        CurvedAnimation(parent: _animController, curve: Curves.easeIn);
    _animController.forward();
    AppState.instance.addListener(_onStateChanged);
  }

  void _onStateChanged() => setState(() {});

  @override
  void dispose() {
    AppState.instance.removeListener(_onStateChanged);
    _animController.dispose();
    super.dispose();
  }

  DateTime _getWeekStart(DateTime date) =>
      date.subtract(Duration(days: date.weekday - 1));

  List<DateTime> get _weekDays =>
      List.generate(7, (i) => _weekStart.add(Duration(days: i)));

  String get _weekRange {
    final end = _weekStart.add(const Duration(days: 6));
    return '${DateFormat('MMMM d').format(_weekStart)}th – ${DateFormat('d').format(end)}th';
  }

  void _onDayTap(DateTime day) {
    setState(() => _selectedDate = day);
    _animController.forward(from: 0);
  }

  @override
  Widget build(BuildContext context) {
    final schedule = AppState.instance.getScheduleForDate(_selectedDate);
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddScheduleSheet(context),
        backgroundColor: const Color(0xFF3B5BDB),
        elevation: 4,
        child: const Icon(Icons.add, color: Colors.white, size: 28),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [_buildAvatarRow(isDark), _buildNotifBell(isDark)],
                  ),
                  const SizedBox(height: 18),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('ACADEMIC CALENDAR',
                          style: GoogleFonts.inter(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFF3B5BDB),
                              letterSpacing: 1.5)),
                      GestureDetector(
                        onTap: () {
                          setState(() {
                            _isMonthView = !_isMonthView;
                            if (_isMonthView) {
                              _weekStart = DateTime(_selectedDate.year, _selectedDate.month, 1);
                              _weekStart = _weekStart.subtract(Duration(days: _weekStart.weekday - 1));
                            } else {
                              _weekStart = _getWeekStart(_selectedDate);
                            }
                          });
                        },
                        child: Icon(
                          _isMonthView ? Icons.view_week_rounded : Icons.calendar_view_month_rounded,
                          color: const Color(0xFF3B5BDB),
                          size: 20,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_isMonthView ? 'Monthly Focus' : 'Weekly Focus',
                              style: GoogleFonts.inter(
                                  fontSize: 28,
                                  fontWeight: FontWeight.w800,
                                  color: theme.textTheme.bodyLarge?.color)),
                          GestureDetector(
                            onTap: () async {
                              final picked = await showDatePicker(
                                context: context,
                                initialDate: _selectedDate,
                                firstDate: DateTime(2000),
                                lastDate: DateTime(2100),
                                builder: (context, child) => Theme(
                                  data: Theme.of(context).copyWith(
                                    colorScheme: const ColorScheme.light(
                                      primary: Color(0xFF3B5BDB),
                                      onPrimary: Colors.white,
                                    ),
                                  ),
                                  child: child!,
                                ),
                              );
                              if (picked != null) {
                                setState(() {
                                  _selectedDate = picked;
                                  if (_isMonthView) {
                                    _weekStart = DateTime(_selectedDate.year, _selectedDate.month, 1);
                                    _weekStart = _weekStart.subtract(Duration(days: _weekStart.weekday - 1));
                                  } else {
                                    _weekStart = _getWeekStart(_selectedDate);
                                  }
                                });
                              }
                            },
                            child: Row(
                              children: [
                                Text(_isMonthView ? DateFormat('MMMM yyyy').format(_selectedDate) : _weekRange,
                                    style: GoogleFonts.inter(
                                        fontSize: 13, color: Colors.grey[500], fontWeight: FontWeight.w600)),
                                const SizedBox(width: 4),
                                Icon(Icons.arrow_drop_down_rounded, size: 20, color: Colors.grey[500]),
                              ],
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          IconButton(
                            icon: const Icon(Icons.chevron_left_rounded),
                            color: const Color(0xFF3B5BDB),
                            onPressed: () {
                              setState(() {
                                if (_isMonthView) {
                                  _selectedDate = DateTime(_selectedDate.year, _selectedDate.month - 1, _selectedDate.day);
                                } else {
                                  _selectedDate = _selectedDate.subtract(const Duration(days: 7));
                                }
                                if (_isMonthView) {
                                  _weekStart = DateTime(_selectedDate.year, _selectedDate.month, 1);
                                  _weekStart = _weekStart.subtract(Duration(days: _weekStart.weekday - 1));
                                } else {
                                  _weekStart = _getWeekStart(_selectedDate);
                                }
                              });
                            },
                          ),
                          IconButton(
                            icon: const Icon(Icons.chevron_right_rounded),
                            color: const Color(0xFF3B5BDB),
                            onPressed: () {
                              setState(() {
                                if (_isMonthView) {
                                  int nextMonth = _selectedDate.month + 1;
                                  int nextYear = _selectedDate.year;
                                  if (nextMonth > 12) {
                                    nextMonth = 1;
                                    nextYear++;
                                  }
                                  int daysInNextMonth = DateTime(nextYear, nextMonth + 1, 0).day;
                                  int newDay = _selectedDate.day > daysInNextMonth ? daysInNextMonth : _selectedDate.day;
                                  _selectedDate = DateTime(nextYear, nextMonth, newDay);
                                } else {
                                  _selectedDate = _selectedDate.add(const Duration(days: 7));
                                }
                                if (_isMonthView) {
                                  _weekStart = DateTime(_selectedDate.year, _selectedDate.month, 1);
                                  _weekStart = _weekStart.subtract(Duration(days: _weekStart.weekday - 1));
                                } else {
                                  _weekStart = _getWeekStart(_selectedDate);
                                }
                              });
                            },
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  AnimatedCrossFade(
                    firstChild: _buildWeekStrip(isDark),
                    secondChild: _buildMonthGrid(isDark),
                    crossFadeState: _isMonthView ? CrossFadeState.showSecond : CrossFadeState.showFirst,
                    duration: const Duration(milliseconds: 300),
                  ),
                  const SizedBox(height: 8),
                ],
              ),
            ),
            Expanded(
              child: FadeTransition(
                opacity: _fadeAnim,
                child: schedule.isEmpty
                    ? _buildEmptyState(isDark)
                    : ListView.builder(
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
                        itemCount: schedule.length,
                        itemBuilder: (context, i) =>
                            _buildScheduleItem(schedule[i], isDark),
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWeekStrip(bool isDark) {
    final dayNames = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(7, (i) {
        final day = _weekDays[i];
        final isSelected = day.day == _selectedDate.day &&
            day.month == _selectedDate.month;
        final isToday = day.day == DateTime.now().day &&
            day.month == DateTime.now().month;
        final hasClass = AppState.instance.hasSchedule(day);

        return GestureDetector(
          onTap: () => _onDayTap(day),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 250),
            width: 44,
            padding: const EdgeInsets.symmetric(vertical: 10),
            decoration: BoxDecoration(
              color: isSelected
                  ? const Color(0xFF3B5BDB)
                  : Colors.transparent,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(children: [
              Text(dayNames[i],
                  style: GoogleFonts.inter(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: isSelected
                          ? Colors.white.withOpacity(0.8)
                          : Colors.grey[500])),
              const SizedBox(height: 6),
              Text('${day.day}',
                  style: GoogleFonts.inter(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: isSelected
                          ? Colors.white
                          : isToday
                              ? const Color(0xFF3B5BDB)
                              : (isDark ? Colors.white : const Color(0xFF1A1A2E)))),
              const SizedBox(height: 4),
              Container(
                  width: 5,
                  height: 5,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: hasClass
                          ? (isSelected
                              ? Colors.white
                              : const Color(0xFF3B5BDB))
                          : Colors.transparent)),
            ]),
          ),
        );
      }),
    );
  }

  Widget _buildMonthGrid(bool isDark) {
    final dayNames = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
    final daysInMonth = DateTime(_selectedDate.year, _selectedDate.month + 1, 0).day;
    final firstDayOfMonth = DateTime(_selectedDate.year, _selectedDate.month, 1);
    final startOffset = firstDayOfMonth.weekday - 1;
    final totalCells = ((daysInMonth + startOffset) / 7).ceil() * 7;

    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: dayNames.map((d) => Text(d, style: GoogleFonts.inter(fontSize: 10, fontWeight: FontWeight.w600, color: Colors.grey[500]))).toList(),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 7,
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
          ),
          itemCount: totalCells,
          itemBuilder: (context, index) {
            final dayOffset = index - startOffset;
            if (dayOffset < 0 || dayOffset >= daysInMonth) {
              return const SizedBox();
            }
            final dayDate = DateTime(_selectedDate.year, _selectedDate.month, dayOffset + 1);
            final isSelected = dayDate.day == _selectedDate.day && dayDate.month == _selectedDate.month;
            final isToday = dayDate.day == DateTime.now().day && dayDate.month == DateTime.now().month && dayDate.year == DateTime.now().year;
            final hasClass = AppState.instance.hasSchedule(dayDate);

            return GestureDetector(
              onTap: () => _onDayTap(dayDate),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                decoration: BoxDecoration(
                  color: isSelected ? const Color(0xFF3B5BDB) : Colors.transparent,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('${dayDate.day}',
                        style: GoogleFonts.inter(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: isSelected
                                ? Colors.white
                                : isToday
                                    ? const Color(0xFF3B5BDB)
                                    : (isDark ? Colors.white : const Color(0xFF1A1A2E)))),
                    if (hasClass) ...[
                      const SizedBox(height: 4),
                      Container(
                          width: 4,
                          height: 4,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: isSelected ? Colors.white : const Color(0xFF3B5BDB))),
                    ]
                  ],
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildScheduleItem(ScheduleItem item, bool isDark) {
    final typeLabel = DummyData.getScheduleTypeLabel(item.type);
    final typeColor = DummyData.getScheduleTypeColor(item.type);
    final timeStr = _formatHour(item.time);

    return Column(children: [
      Row(children: [
        Container(
          width: 10,
          height: 10,
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: item.color,
              boxShadow: [
                BoxShadow(
                    color: item.color.withOpacity(0.4), blurRadius: 6)
              ]),
        ),
        const SizedBox(width: 10),
        Text('$timeStr  •  ${item.durationMinutes} mins',
            style: GoogleFonts.inter(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Colors.grey[500])),
      ]),
      const SizedBox(height: 10),
      GestureDetector(
        onLongPress: () => _confirmDeleteSchedule(item, isDark),
        child: Container(
          margin: const EdgeInsets.only(bottom: 16, left: 20),
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF2A2A40) : Colors.white,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 12,
                  offset: const Offset(0, 4))
            ],
          ),
          child: Row(children: [
            Container(
                width: 4,
                height: 50,
                decoration: BoxDecoration(
                    color: item.color,
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(item.title,
                                style: GoogleFonts.inter(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    color: isDark ? Colors.white : const Color(0xFF1A1A2E))),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                                color: typeColor.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(20)),
                            child: Text(typeLabel,
                                style: GoogleFonts.inter(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w700,
                                    color: typeColor,
                                    letterSpacing: 0.5)),
                          ),
                        ]),
                    const SizedBox(height: 8),
                    Row(children: [
                      Icon(Icons.location_on_outlined,
                          size: 13, color: Colors.grey[500]),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(item.location,
                            style: GoogleFonts.inter(
                                fontSize: 12, color: Colors.grey[500]),
                            overflow: TextOverflow.ellipsis),
                      ),
                      const SizedBox(width: 8),
                      Icon(Icons.person_outline,
                          size: 13, color: Colors.grey[500]),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(item.instructor,
                            style: GoogleFonts.inter(
                                fontSize: 12, color: Colors.grey[500]),
                            overflow: TextOverflow.ellipsis),
                      ),
                    ]),
                  ]),
            ),
          ]),
        ),
      ),
    ]);
  }

  void _confirmDeleteSchedule(ScheduleItem item, bool isDark) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: isDark ? const Color(0xFF2A2A40) : Colors.white,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Delete Schedule',
            style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: isDark ? Colors.white : const Color(0xFF1A1A2E))),
        content: Text(
            'Remove "${item.title}" from your schedule?',
            style:
                GoogleFonts.inter(fontSize: 14, color: Colors.grey[500])),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: Text('Cancel',
                  style: GoogleFonts.inter(
                      fontWeight: FontWeight.w600,
                      color: Colors.grey[500]))),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12))),
            child: Text('Delete',
                style:
                    GoogleFonts.inter(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      AppState.instance.deleteSchedule(_selectedDate, item.id);
    }
  }

  String _formatHour(TimeOfDay t) {
    final hour = t.hour;
    final min = t.minute.toString().padLeft(2, '0');
    final period = hour < 12 ? 'AM' : 'PM';
    final h = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
    return '${h.toString().padLeft(2, '0')}:$min $period';
  }

  Widget _buildEmptyState(bool isDark) => Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
                color: const Color(0xFF3B5BDB).withOpacity(0.1),
                shape: BoxShape.circle),
            child: const Icon(Icons.weekend_outlined,
                size: 40, color: Color(0xFF3B5BDB)),
          ),
          const SizedBox(height: 16),
          Text('No Classes Today!',
              style: GoogleFonts.inter(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: isDark ? Colors.white : const Color(0xFF1A1A2E))),
          const SizedBox(height: 6),
          Text('Tap + to add a class for this day 📚',
              style:
                  GoogleFonts.inter(fontSize: 13, color: Colors.grey[400])),
        ]),
      );

  Widget _buildAvatarRow(bool isDark) => Row(children: [
        Container(
          width: 44,
          height: 44,
          decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                  colors: [Color(0xFF3B5BDB), Color(0xFF74C0FC)])),
          child:
              const Icon(Icons.person, color: Colors.white, size: 24),
        ),
        const SizedBox(width: 12),
        Text('Hello, ${AppState.instance.currentUser?.name.split(' ').first ?? 'Friend'}!',
            style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: isDark ? Colors.white : const Color(0xFF1A1A2E))),
      ]);

  Widget _buildNotifBell(bool isDark) => GestureDetector(
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const NotificationsScreen())),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF2A2A40) : Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 8,
                  offset: const Offset(0, 2))
            ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Icon(Icons.notifications_outlined,
                  color: Color(0xFF3B5BDB), size: 22),
              if (AppState.instance.unreadNotificationCount > 0)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                        color: Color(0xFFF03E3E), shape: BoxShape.circle),
                    constraints: const BoxConstraints(
                      minWidth: 12,
                      minHeight: 12,
                    ),
                  ),
                ),
            ],
          ),
        ),
      );

  void _showAddScheduleSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _AddScheduleSheet(
        selectedDate: _selectedDate,
        onAdd: (item, repeats) =>
            AppState.instance.addSchedule(_selectedDate, item, repeatWeeks: repeats),
      ),
    );
  }
}

// ─── Add Schedule Sheet ──────────────────────────────────────────────────────

class _AddScheduleSheet extends StatefulWidget {
  final DateTime selectedDate;
  final void Function(ScheduleItem, int) onAdd;

  const _AddScheduleSheet(
      {required this.selectedDate, required this.onAdd});

  @override
  State<_AddScheduleSheet> createState() => _AddScheduleSheetState();
}

class _AddScheduleSheetState extends State<_AddScheduleSheet> {
  final _titleCtrl = TextEditingController();
  final _locationCtrl = TextEditingController();
  final _instructorCtrl = TextEditingController();
  int _hour = 8;
  int _minute = 0;
  int _duration = 90;
  ScheduleType _type = ScheduleType.lecture;
  String _colorKey = 'Blue';
  bool _repeatWeekly = false;
  late DateTime _targetDate;

  @override
  void initState() {
    super.initState();
    _targetDate = widget.selectedDate;
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _locationCtrl.dispose();
    _instructorCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final cardColor = isDark ? const Color(0xFF2A2A40) : Colors.white;
    final fieldColor = isDark ? const Color(0xFF1E1E30) : const Color(0xFFF4F6FB);
    final textColor = isDark ? Colors.white : const Color(0xFF1A1A2E);

    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: isDark ? Colors.grey[700] : Colors.grey[300],
                        borderRadius: BorderRadius.circular(2))),
              ),
              const SizedBox(height: 20),
              Text('Add Schedule',
                  style: GoogleFonts.inter(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: textColor)),
              GestureDetector(
                onTap: () async {
                  final picked = await showDatePicker(
                    context: context,
                    initialDate: _targetDate,
                    firstDate: DateTime.now().subtract(const Duration(days: 365)),
                    lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
                    builder: (context, child) => Theme(
                      data: Theme.of(context).copyWith(
                        colorScheme: const ColorScheme.light(
                          primary: Color(0xFF3B5BDB),
                          onPrimary: Colors.white,
                        ),
                      ),
                      child: child!,
                    ),
                  );
                  if (picked != null) {
                    setState(() => _targetDate = picked);
                  }
                },
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                        DateFormat('EEEE, MMMM d').format(_targetDate),
                        style: GoogleFonts.inter(
                            fontSize: 13, color: const Color(0xFF3B5BDB), fontWeight: FontWeight.w600)),
                    const SizedBox(width: 4),
                    const Icon(Icons.edit_calendar_rounded, size: 14, color: Color(0xFF3B5BDB)),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              _field(_titleCtrl, 'Subject / Class Title *',
                  Icons.school_outlined, fieldColor, textColor),
              const SizedBox(height: 12),
              _field(_locationCtrl, 'Location / Room',
                  Icons.location_on_outlined, fieldColor, textColor),
              const SizedBox(height: 12),
              _field(_instructorCtrl, 'Instructor / Lecturer',
                  Icons.person_outline, fieldColor, textColor),
              const SizedBox(height: 16),
              _label('Start Time', isDark),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () async {
                      final t = await showTimePicker(
                          context: context,
                          initialTime:
                              TimeOfDay(hour: _hour, minute: _minute));
                      if (t != null) {
                        setState(() {
                          _hour = t.hour;
                          _minute = t.minute;
                        });
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                          color: fieldColor,
                          borderRadius: BorderRadius.circular(12)),
                      child: Row(children: [
                        Icon(Icons.access_time,
                            color: Colors.grey[500], size: 20),
                        const SizedBox(width: 10),
                        Text(
                            '${_hour.toString().padLeft(2, '0')}:${_minute.toString().padLeft(2, '0')}',
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: textColor)),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                        color: fieldColor,
                        borderRadius: BorderRadius.circular(12)),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<int>(
                        value: _duration,
                        dropdownColor: cardColor,
                        style: GoogleFonts.inter(
                            fontSize: 14,
                            color: textColor),
                        items: [60, 90, 120, 150, 180].map((d) {
                          return DropdownMenuItem(
                              value: d, child: Text('$d min'));
                        }).toList(),
                        onChanged: (v) =>
                            setState(() => _duration = v!),
                      ),
                    ),
                  ),
                ),
              ]),
              const SizedBox(height: 16),
              _label('Type', isDark),
              const SizedBox(height: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                    color: fieldColor,
                    borderRadius: BorderRadius.circular(12)),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<ScheduleType>(
                    value: _type,
                    isExpanded: true,
                    dropdownColor: cardColor,
                    style: GoogleFonts.inter(
                        fontSize: 14, color: textColor),
                    items: ScheduleType.values.map((t) {
                      return DropdownMenuItem(
                          value: t,
                          child: Text(
                              DummyData.getScheduleTypeLabel(t)));
                    }).toList(),
                    onChanged: (v) => setState(() => _type = v!),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              _label('Color', isDark),
              const SizedBox(height: 8),
              Row(
                children: DummyData.scheduleColors.entries.map((e) {
                  final selected = _colorKey == e.key;
                  return GestureDetector(
                    onTap: () => setState(() => _colorKey = e.key),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.only(right: 10),
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: e.value,
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: selected
                                ? Colors.white
                                : Colors.transparent,
                            width: 3),
                        boxShadow: selected
                            ? [
                                BoxShadow(
                                    color: e.value.withOpacity(0.5),
                                    blurRadius: 8)
                              ]
                            : [],
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Repeat weekly (for 12 weeks)',
                      style: GoogleFonts.inter(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: textColor)),
                  Switch(
                    value: _repeatWeekly,
                    activeColor: const Color(0xFF3B5BDB),
                    onChanged: (v) => setState(() => _repeatWeekly = v),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    if (_titleCtrl.text.trim().isEmpty) return;
                    final item = ScheduleItem(
                      id: DateTime.now()
                          .millisecondsSinceEpoch
                          .toString(),
                      title: _titleCtrl.text.trim(),
                      location: _locationCtrl.text.trim().isEmpty
                          ? 'TBD'
                          : _locationCtrl.text.trim(),
                      instructor:
                          _instructorCtrl.text.trim().isEmpty
                              ? 'TBD'
                              : _instructorCtrl.text.trim(),
                      time: TimeOfDay(hour: _hour, minute: _minute),
                      durationMinutes: _duration,
                      type: _type,
                      color: DummyData.scheduleColors[_colorKey]!,
                      date: _targetDate,
                    );
                    widget.onAdd(item, _repeatWeekly ? 12 : 1);
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF3B5BDB),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    elevation: 0,
                  ),
                  child: Text('Add to Schedule',
                      style: GoogleFonts.inter(
                          fontSize: 15, fontWeight: FontWeight.w700)),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController ctrl, String hint, IconData icon,
          Color fieldColor, Color textColor) =>
      Container(
        decoration: BoxDecoration(
            color: fieldColor,
            borderRadius: BorderRadius.circular(12)),
        child: TextField(
          controller: ctrl,
          style: GoogleFonts.inter(
              fontSize: 14, color: textColor),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle:
                GoogleFonts.inter(fontSize: 14, color: Colors.grey[500]),
            prefixIcon: Icon(icon, color: Colors.grey[500], size: 20),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 14),
          ),
        ),
      );

  Widget _label(String text, bool isDark) => Text(text,
      style: GoogleFonts.inter(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: isDark ? Colors.grey[400] : Colors.grey[600]));
}
