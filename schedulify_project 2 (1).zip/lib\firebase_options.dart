// File generated from google-services.json
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        throw UnsupportedError(
          'iOS requires GoogleService-Info.plist. '
          'Run: flutterfire configure',
        );
      default:
        return android;
    }
  }

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyAwWE82J7LXxWi31GkKaUbydnMoe9K3y-k',
    appId: '1:773857981617:web:schedulify',
    messagingSenderId: '773857981617',
    projectId: 'schedulify-caff9',
    storageBucket: 'schedulify-caff9.firebasestorage.app',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAwWE82J7LXxWi31GkKaUbydnMoe9K3y-k',
    appId: '1:773857981617:android:4e175b4e8a368951eede90',
    messagingSenderId: '773857981617',
    projectId: 'schedulify-caff9',
    storageBucket: 'schedulify-caff9.firebasestorage.app',
  );
}
