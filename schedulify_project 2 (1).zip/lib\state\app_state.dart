import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/app_models.dart';

// ─── User Model ─────────────────────────────────────────────────────────────
class AppUser {
  final String uid;
  final String name;
  final String email;
  final String major;
  final int semester;

  AppUser({
    required this.uid,
    required this.name,
    required this.email,
    this.major = 'Computer Science',
    this.semester = 1,
  });

  Map<String, dynamic> toJson() => {
        'uid': uid,
        'name': name,
        'email': email,
        'major': major,
        'semester': semester,
      };

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        uid: json['uid'] ?? '',
        name: json['name'] ?? '',
        email: json['email'] ?? '',
        major: json['major'] ?? 'Computer Science',
        semester: (json['semester'] ?? 1) as int,
      );
}

/// Singleton state manager backed by Firebase Auth + Cloud Firestore.
class AppState extends ChangeNotifier {
  static final AppState instance = AppState._internal();
  factory AppState() => instance;
  AppState._internal();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  bool _isInitialized = false;
  bool get isInitialized => _isInitialized;

  List<Task> _tasks = [];
  AppUser? _currentUser;
  bool _isDarkMode = false;
  final Map<String, List<ScheduleItem>> _extraSchedules = {};
  final List<AppNotification> _notifications = [];

  bool get isDarkMode => _isDarkMode;
  AppUser? get currentUser => _currentUser;

  void toggleDarkMode() {
    _isDarkMode = !_isDarkMode;
    _saveSettings();
    notifyListeners();
  }

  // ─── Init ──────────────────────────────────────────────────────────────────

  Future<void> init() async {
    if (_isInitialized) return;
    final user = _auth.currentUser;
    if (user != null) {
      await _loadUserData(user.uid);
    }
    _isInitialized = true;
    notifyListeners();
  }

  // ─── Load from Firestore ───────────────────────────────────────────────────

  Future<void> _loadUserData(String uid) async {
    try {
      // Profile
      final userDoc = await _db.collection('users').doc(uid).get();
      if (userDoc.exists) {
        final data = userDoc.data()!;
        _currentUser = AppUser(
          uid: uid,
          name: data['name'] ?? '',
          email: data['email'] ?? '',
          major: data['major'] ?? 'Computer Science',
          semester: (data['semester'] ?? 1) as int,
        );
        _isDarkMode = data['isDarkMode'] ?? false;
      }

      // Tasks
      final tasksSnap = await _db
          .collection('users')
          .doc(uid)
          .collection('tasks')
          .get();
      _tasks = tasksSnap.docs.map((d) => Task.fromJson(d.data())).toList();
      // Notifications
      _notifications.clear();
      final notifsSnap = await _db
          .collection('users')
          .doc(uid)
          .collection('notifications')
          .get();
      _notifications
          .addAll(notifsSnap.docs.map((d) => AppNotification.fromJson(d.data())));

      // Extra Schedules
      _extraSchedules.clear();
      final schedulesSnap = await _db
          .collection('users')
          .doc(uid)
          .collection('schedules')
          .get();
      for (final doc in schedulesSnap.docs) {
        final items = (doc.data()['items'] as List<dynamic>? ?? [])
            .map((s) => ScheduleItem.fromJson(s as Map<String, dynamic>))
            .toList();
        _extraSchedules[doc.id] = items;
      }
    } catch (e) {
      debugPrint('Error loading user data: $e');
    }
  }

  // ─── Save to Firestore ─────────────────────────────────────────────────────

  Future<void> _saveSettings() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    try {
      await _db
          .collection('users')
          .doc(uid)
          .update({'isDarkMode': _isDarkMode});
    } catch (_) {}
  }

  Future<void> _saveTasks({String? uid}) async {
    uid ??= _auth.currentUser?.uid;
    if (uid == null) return;
    try {
      final colRef = _db.collection('users').doc(uid).collection('tasks');
      final batch = _db.batch();
      final existing = await colRef.get();
      for (final doc in existing.docs) {
        batch.delete(doc.reference);
      }
      for (final task in _tasks) {
        batch.set(colRef.doc(task.id), task.toJson());
      }
      await batch.commit();
    } catch (e) {
      debugPrint('Error saving tasks: $e');
    }
  }

  Future<void> _saveNotifications() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    try {
      final colRef =
          _db.collection('users').doc(uid).collection('notifications');
      final batch = _db.batch();
      final existing = await colRef.get();
      for (final doc in existing.docs) {
        batch.delete(doc.reference);
      }
      for (final notif in _notifications) {
        batch.set(colRef.doc(notif.id), notif.toJson());
      }
      await batch.commit();
    } catch (e) {
      debugPrint('Error saving notifications: $e');
    }
  }

  Future<void> _saveSchedules() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;
    try {
      final colRef =
          _db.collection('users').doc(uid).collection('schedules');
      final batch = _db.batch();
      for (final entry in _extraSchedules.entries) {
        batch.set(colRef.doc(entry.key), {
          'items': entry.value.map((s) => s.toJson()).toList(),
        });
      }
      await batch.commit();
    } catch (e) {
      debugPrint('Error saving schedules: $e');
    }
  }

  // ─── Auth ──────────────────────────────────────────────────────────────────

  Future<String?> register({
    required String name,
    required String email,
    required String password,
    required String major,
    required int semester,
  }) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim().toLowerCase(),
        password: password,
      );
      final uid = cred.user!.uid;
      final user = AppUser(
        uid: uid,
        name: name.trim(),
        email: email.trim().toLowerCase(),
        major: major,
        semester: semester,
      );

      await _db.collection('users').doc(uid).set({
        'uid': uid,
        'name': user.name,
        'email': user.email,
        'major': user.major,
        'semester': user.semester,
        'isDarkMode': false,
      });

      _currentUser = user;
      _isDarkMode = false;
      _tasks = [];
      _notifications.clear();
      _extraSchedules.clear();
      await _saveTasks(uid: uid);
      notifyListeners();
      return null;
    } on FirebaseAuthException catch (e) {
      switch (e.code) {
        case 'email-already-in-use':
          return 'Email sudah terdaftar.';
        case 'weak-password':
          return 'Password terlalu lemah (min 6 karakter).';
        case 'invalid-email':
          return 'Format email tidak valid.';
        default:
          return e.message ?? 'Terjadi kesalahan.';
      }
    } catch (e) {
      return 'Terjadi kesalahan: $e';
    }
  }

  Future<String?> login(String email, String password) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(
        email: email.trim().toLowerCase(),
        password: password,
      );
      await _loadUserData(cred.user!.uid);
      notifyListeners();
      return null;
    } on FirebaseAuthException catch (e) {
      switch (e.code) {
        case 'user-not-found':
        case 'invalid-credential':
        case 'wrong-password':
          return 'Email atau password salah.';
        case 'invalid-email':
          return 'Format email tidak valid.';
        case 'too-many-requests':
          return 'Terlalu banyak percobaan. Coba lagi nanti.';
        default:
          return e.message ?? 'Terjadi kesalahan.';
      }
    } catch (e) {
      return 'Terjadi kesalahan: $e';
    }
  }

  Future<String?> resetPassword(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email.trim().toLowerCase());
      return null; // Success
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found' || e.code == 'invalid-email') {
        return 'Email tidak ditemukan atau format salah.';
      }
      return e.message ?? 'Terjadi kesalahan saat mengirim link reset.';
    } catch (e) {
      return 'Terjadi kesalahan: $e';
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
    _currentUser = null;
    _tasks = [];
    _notifications.clear();
    _extraSchedules.clear();
    _isDarkMode = false;
    notifyListeners();
  }

  Future<bool> changePassword(String oldPass, String newPass) async {
    final user = _auth.currentUser;
    if (user == null || user.email == null) return false;
    try {
      final cred = EmailAuthProvider.credential(
        email: user.email!,
        password: oldPass,
      );
      await user.reauthenticateWithCredential(cred);
      await user.updatePassword(newPass);
      return true;
    } catch (_) {
      return false;
    }
  }

  Future<void> updateCurrentUser({
    required String name,
    required String email,
    String? major,
    int? semester,
  }) async {
    final uid = _auth.currentUser?.uid;
    if (uid == null || _currentUser == null) return;

    final updated = AppUser(
      uid: uid,
      name: name.trim().isEmpty ? _currentUser!.name : name.trim(),
      email: _currentUser!.email,
      major: major ?? _currentUser!.major,
      semester: semester ?? _currentUser!.semester,
    );

    await _db.collection('users').doc(uid).update({
      'name': updated.name,
      'major': updated.major,
      'semester': updated.semester,
    });

    _currentUser = updated;
    notifyListeners();
  }

  // ─── Analytics ────────────────────────────────────────────────────────────

  List<Task> getUpcomingTasks({int hours = 2}) {
    final now = DateTime.now();
    final threshold = now.add(Duration(hours: hours));
    return _tasks
        .where((t) =>
            !t.isCompleted &&
            t.dueDate.isAfter(now) &&
            t.dueDate.isBefore(threshold))
        .toList();
  }

  List<Task> get overdueTasks {
    final now = DateTime.now();
    return _tasks.where((t) => !t.isCompleted && t.dueDate.isBefore(now)).toList();
  }

  // ─── Notifications ────────────────────────────────────────────────────────

  List<AppNotification> get notifications => List.unmodifiable(_notifications);
  int get unreadNotificationCount =>
      _notifications.where((n) => !n.isRead).length;

  void addNotification(
      {required String title, required String body, bool isOverdue = false}) {
    _notifications.insert(
        0,
        AppNotification(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          title: title,
          body: body,
          timestamp: DateTime.now(),
          isOverdue: isOverdue,
        ));
    _saveNotifications();
    notifyListeners();
  }

  void markNotificationRead(String id) {
    final idx = _notifications.indexWhere((n) => n.id == id);
    if (idx != -1) {
      _notifications[idx].isRead = true;
      _saveNotifications();
      notifyListeners();
    }
  }

  void markAllNotificationsRead() {
    for (var n in _notifications) {
      n.isRead = true;
    }
    _saveNotifications();
    notifyListeners();
  }

  // ─── Tasks ────────────────────────────────────────────────────────────────

  List<Task> get tasks => List.unmodifiable(_tasks);
  int get completedCount => _tasks.where((t) => t.isCompleted).length;
  int get pendingCount => _tasks.where((t) => !t.isCompleted).length;
  int get totalCount => _tasks.length;

  void addTask(Task task) {
    _tasks.add(task);
    _saveTasks();
    notifyListeners();
  }

  void updateTask(Task updated) {
    final i = _tasks.indexWhere((t) => t.id == updated.id);
    if (i != -1) {
      _tasks[i] = updated;
      _saveTasks();
      notifyListeners();
    }
  }

  void deleteTask(String id) {
    _tasks.removeWhere((t) => t.id == id);
    _saveTasks();
    notifyListeners();
  }

  void toggleTask(String id) {
    final i = _tasks.indexWhere((t) => t.id == id);
    if (i != -1) {
      _tasks[i].isCompleted = !_tasks[i].isCompleted;
      _saveTasks();
      notifyListeners();
    }
  }

  // ─── Schedules ────────────────────────────────────────────────────────────

  List<ScheduleItem> getScheduleForDate(DateTime date) {
    final key = _key(date);
    return _extraSchedules[key] ?? [];
  }

  bool hasSchedule(DateTime date) => getScheduleForDate(date).isNotEmpty;

  void addSchedule(DateTime date, ScheduleItem item, {int repeatWeeks = 1}) {
    for (int i = 0; i < repeatWeeks; i++) {
      final targetDate = date.add(Duration(days: 7 * i));
      final key = _key(targetDate);
      // Copy item so each week has correct date
      final repeatedItem = ScheduleItem(
        id: '${item.id}_$i',
        title: item.title,
        location: item.location,
        instructor: item.instructor,
        time: item.time,
        durationMinutes: item.durationMinutes,
        type: item.type,
        color: item.color,
        date: targetDate,
      );
      _extraSchedules.putIfAbsent(key, () => []).add(repeatedItem);
    }
    _saveSchedules();
    notifyListeners();
  }

  void deleteSchedule(DateTime date, String id) {
    final key = _key(date);
    if (_extraSchedules.containsKey(key)) {
      _extraSchedules[key]!.removeWhere((s) => s.id == id);
      _saveSchedules();
      notifyListeners();
    }
  }

  String _key(DateTime d) => '${d.year}-${d.month}-${d.day}';
}
