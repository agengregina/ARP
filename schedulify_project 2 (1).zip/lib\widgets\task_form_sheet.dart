import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/app_models.dart';

/// Shared bottom sheet form for Add & Edit Task.
/// Used by HomeTab and TasksTab.
class TaskFormSheet extends StatefulWidget {
  final Task? task; // null = add new, non-null = edit existing
  final void Function(Task) onSave;

  const TaskFormSheet({super.key, this.task, required this.onSave});

  @override
  State<TaskFormSheet> createState() => _TaskFormSheetState();
}

class _TaskFormSheetState extends State<TaskFormSheet> {
  late TextEditingController _titleCtrl;
  late TextEditingController _descCtrl;
  late String _category;
  late TaskStatus _status;
  late TaskPriority _priority;
  late DateTime _dueDate;
  late TimeOfDay _dueTime;

  @override
  void initState() {
    super.initState();
    _titleCtrl = TextEditingController(text: widget.task?.title ?? '');
    _descCtrl = TextEditingController(text: widget.task?.description ?? '');
    _category = widget.task?.category ?? 'CS';
    _status = widget.task?.status ?? TaskStatus.assigned;
    _priority = widget.task?.priority ?? TaskPriority.medium;
    final due = widget.task?.dueDate ?? DateTime.now().add(const Duration(days: 7));
    _dueDate = due;
    _dueTime = TimeOfDay(hour: due.hour, minute: due.minute);
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _dueDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: const ColorScheme.light(
            primary: Color(0xFF3B5BDB),
            onPrimary: Colors.white,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _dueDate = picked);
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(
      context: context,
      initialTime: _dueTime,
      builder: (context, child) => Theme(
        data: Theme.of(context).copyWith(
          colorScheme: const ColorScheme.light(
            primary: Color(0xFF3B5BDB),
            onPrimary: Colors.white,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) setState(() => _dueTime = picked);
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.task != null;
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final cardColor = isDark ? const Color(0xFF2A2A40) : Colors.white;
    final fieldColor = isDark ? const Color(0xFF1E1E30) : const Color(0xFFF4F6FB);
    final textColor = isDark ? Colors.white : const Color(0xFF1A1A2E);

    final dateStr = DateFormat('EEE, MMM d, yyyy').format(_dueDate);
    final hourStr = _dueTime.hour.toString().padLeft(2, '0');
    final minStr = _dueTime.minute.toString().padLeft(2, '0');
    final period = _dueTime.hour < 12 ? 'AM' : 'PM';
    final h = _dueTime.hour > 12 ? _dueTime.hour - 12 : (_dueTime.hour == 0 ? 12 : _dueTime.hour);
    final timeStr = '${h.toString().padLeft(2, '0')}:$minStr $period';

    return Padding(
      padding:
          EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Handle bar
              Center(
                child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                        color: isDark ? Colors.grey[700] : Colors.grey[300],
                        borderRadius: BorderRadius.circular(2))),
              ),
              const SizedBox(height: 20),
              Text(isEdit ? 'Edit Task' : 'Add New Task',
                  style: GoogleFonts.inter(
                      fontSize: 20,
                      fontWeight: FontWeight.w800,
                      color: textColor)),
              const SizedBox(height: 20),
              _field(_titleCtrl, 'Task Title *', Icons.task_alt_outlined,
                  fieldColor, textColor),
              const SizedBox(height: 12),
              _field(_descCtrl, 'Description (optional)', Icons.notes,
                  fieldColor, textColor),
              const SizedBox(height: 16),

              // ── Deadline ──
              _label('Deadline', isDark),
              const SizedBox(height: 8),
              Row(children: [
                // Date picker
                Expanded(
                  flex: 3,
                  child: GestureDetector(
                    onTap: _pickDate,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 14),
                      decoration: BoxDecoration(
                          color: fieldColor,
                          borderRadius: BorderRadius.circular(12)),
                      child: Row(children: [
                        Icon(Icons.calendar_today_outlined,
                            color: const Color(0xFF3B5BDB), size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(dateStr,
                              style: GoogleFonts.inter(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: textColor)),
                        ),
                      ]),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                // Time picker
                Expanded(
                  flex: 2,
                  child: GestureDetector(
                    onTap: _pickTime,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 14),
                      decoration: BoxDecoration(
                          color: fieldColor,
                          borderRadius: BorderRadius.circular(12)),
                      child: Row(children: [
                        Icon(Icons.access_time_rounded,
                            color: const Color(0xFF3B5BDB), size: 18),
                        const SizedBox(width: 8),
                        Text(timeStr,
                            style: GoogleFonts.inter(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: textColor)),
                      ]),
                    ),
                  ),
                ),
              ]),
              const SizedBox(height: 16),

              // ── Category ──
              _label('Category', isDark),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: DummyData.categories.map((cat) {
                  final sel = _category == cat;
                  return GestureDetector(
                    onTap: () => setState(() => _category = cat),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                          color: sel ? const Color(0xFF3B5BDB) : fieldColor,
                          borderRadius: BorderRadius.circular(30)),
                      child: Text(cat,
                          style: GoogleFonts.inter(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: sel
                                  ? Colors.white
                                  : (isDark
                                      ? Colors.grey[400]
                                      : Colors.grey[600]))),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),

              // ── Status ──
              _label('Status', isDark),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                    color: fieldColor,
                    borderRadius: BorderRadius.circular(12)),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<TaskStatus>(
                    value: _status,
                    isExpanded: true,
                    dropdownColor: cardColor,
                    style: GoogleFonts.inter(fontSize: 14, color: textColor),
                    items: TaskStatus.values.map((s) {
                      return DropdownMenuItem(
                          value: s,
                          child: Text(DummyData.getStatusLabel(s)));
                    }).toList(),
                    onChanged: (v) => setState(() => _status = v!),
                  ),
                ),
              ),
              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    if (_titleCtrl.text.trim().isEmpty) return;
                    final deadline = DateTime(
                      _dueDate.year,
                      _dueDate.month,
                      _dueDate.day,
                      _dueTime.hour,
                      _dueTime.minute,
                    );
                    final task = widget.task?.copyWith(
                              title: _titleCtrl.text.trim(),
                              description: _descCtrl.text.trim(),
                              category: _category,
                              status: _status,
                              priority: _priority,
                              dueDate: deadline,
                            ) ??
                        Task(
                          id: DateTime.now()
                              .millisecondsSinceEpoch
                              .toString(),
                          title: _titleCtrl.text.trim(),
                          description: _descCtrl.text.trim(),
                          category: _category,
                          dueDate: deadline,
                          status: _status,
                          priority: _priority,
                        );
                    widget.onSave(task);
                    Navigator.pop(context);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF3B5BDB),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    elevation: 0,
                  ),
                  child: Text(isEdit ? 'Save Changes' : 'Add Task',
                      style: GoogleFonts.inter(
                          fontSize: 15, fontWeight: FontWeight.w700)),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController ctrl, String hint, IconData icon,
          Color fieldColor, Color textColor) =>
      Container(
        decoration: BoxDecoration(
            color: fieldColor,
            borderRadius: BorderRadius.circular(12)),
        child: TextField(
          controller: ctrl,
          style: GoogleFonts.inter(fontSize: 14, color: textColor),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle:
                GoogleFonts.inter(fontSize: 14, color: Colors.grey[500]),
            prefixIcon: Icon(icon, color: Colors.grey[500], size: 20),
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          ),
        ),
      );

  Widget _label(String text, bool isDark) => Text(text,
      style: GoogleFonts.inter(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          color: isDark ? Colors.grey[400] : Colors.grey[600]));
}
