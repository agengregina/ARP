import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/app_models.dart';
import '../state/app_state.dart';
import '../widgets/task_form_sheet.dart';
import 'notifications_screen.dart';
import 'main_navigation.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const MainNavigation();
  }
}

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> with SingleTickerProviderStateMixin {
  late AnimationController _animController;
  late Animation<double> _fadeAnim;
  final DateTime today = DateTime.now();

  String get _userName =>
      AppState.instance.currentUser?.name.split(' ').first ?? 'Friend';

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _fadeAnim =
        CurvedAnimation(parent: _animController, curve: Curves.easeIn);
    _animController.forward();
    AppState.instance.addListener(_onStateChanged);
  }

  void _onStateChanged() => setState(() {});

  @override
  void dispose() {
    AppState.instance.removeListener(_onStateChanged);
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppState.instance;
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final todaySchedule = state.getScheduleForDate(today);
    final pendingTasks = state.tasks.where((t) => !t.isCompleted).toList()
      ..sort((a, b) => a.dueDate.compareTo(b.dueDate));
    final priorityTask = pendingTasks.isNotEmpty ? pendingTasks.first : null;

    return FadeTransition(
      opacity: _fadeAnim,
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,
        floatingActionButton: FloatingActionButton(
          onPressed: () => _showAddTaskSheet(context),
          backgroundColor: const Color(0xFF3B5BDB),
          elevation: 4,
          child: const Icon(Icons.add, color: Colors.white, size: 28),
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Top Bar
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(children: [
                      _buildAvatar(),
                      const SizedBox(width: 12),
                      Text('Hello, $_userName!',
                          style: GoogleFonts.inter(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: theme.textTheme.bodyLarge?.color)),
                    ]),
                    _buildNotifBell(isDark),
                  ],
                ),
                const SizedBox(height: 20),
                Text(
                  DateFormat('EEEE, MMM d').format(today).toUpperCase(),
                  style: GoogleFonts.inter(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey[500],
                      letterSpacing: 1.2),
                ),
                const SizedBox(height: 4),
                Text(
                  '${DummyData.getGreeting()}, $_userName',
                  style: GoogleFonts.inter(
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      color: theme.textTheme.bodyLarge?.color),
                ),
                const SizedBox(height: 24),

                // Priority Task
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('Priority Task',
                        style: GoogleFonts.inter(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: theme.textTheme.bodyLarge?.color)),
                    Text('${pendingTasks.length} pending',
                        style: GoogleFonts.inter(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF3B5BDB))),
                  ],
                ),
                const SizedBox(height: 12),
                priorityTask == null
                    ? _buildNoPriorityCard(isDark)
                    : _buildPriorityCard(priorityTask),
                const SizedBox(height: 28),

                // Today Schedule
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Today's Schedule",
                        style: GoogleFonts.inter(
                            fontSize: 18,
                            fontWeight: FontWeight.w700,
                            color: theme.textTheme.bodyLarge?.color)),
                    Text('${todaySchedule.length} classes',
                        style: GoogleFonts.inter(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF3B5BDB))),
                  ],
                ),
                const SizedBox(height: 14),
                if (todaySchedule.isEmpty)
                  _buildEmptySchedule(isDark)
                else
                  ...todaySchedule.map((item) => _buildScheduleCard(item, isDark)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAvatar() => Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: const LinearGradient(
              colors: [Color(0xFF3B5BDB), Color(0xFF74C0FC)]),
          boxShadow: [
            BoxShadow(
                color: const Color(0xFF3B5BDB).withOpacity(0.3),
                blurRadius: 8,
                offset: const Offset(0, 3)),
          ],
        ),
        child: const Icon(Icons.person, color: Colors.white, size: 24),
      );

  Widget _buildNotifBell(bool isDark) => GestureDetector(
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const NotificationsScreen())),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF2A2A40) : Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 8,
                  offset: const Offset(0, 2)),
            ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Icon(Icons.notifications_outlined,
                  color: Color(0xFF3B5BDB), size: 22),
              if (AppState.instance.unreadNotificationCount > 0)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                        color: Color(0xFFF03E3E), shape: BoxShape.circle),
                    constraints: const BoxConstraints(
                      minWidth: 12,
                      minHeight: 12,
                    ),
                  ),
                ),
            ],
          ),
        ),
      );

  Widget _buildPriorityCard(Task task) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
              colors: [Color(0xFF3B5BDB), Color(0xFF748FFC)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
                color: const Color(0xFF3B5BDB).withOpacity(0.35),
                blurRadius: 20,
                offset: const Offset(0, 8)),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              const Icon(Icons.warning_amber_rounded,
                  color: Colors.amber, size: 16),
              const SizedBox(width: 6),
              Text('DEADLINE APPROACHING',
                  style: GoogleFonts.inter(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Colors.white.withOpacity(0.9),
                      letterSpacing: 0.8)),
            ]),
            const SizedBox(height: 12),
            Text(task.title,
                style: GoogleFonts.inter(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Colors.white)),
            const SizedBox(height: 6),
            Text(task.description,
                style: GoogleFonts.inter(
                    fontSize: 13, color: Colors.white.withOpacity(0.8))),
            const SizedBox(height: 16),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(30)),
              child: Text(
                  'Due: ${DateFormat('MMM d').format(task.dueDate)}',
                  style: GoogleFonts.inter(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.white)),
            ),
          ],
        ),
      );

  Widget _buildNoPriorityCard(bool isDark) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF2A2A40) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 10,
                offset: const Offset(0, 3)),
          ],
        ),
        child: Row(children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
                color: const Color(0xFF2F9E44).withOpacity(0.1),
                shape: BoxShape.circle),
            child: const Icon(Icons.check_circle_outline,
                color: Color(0xFF2F9E44), size: 26),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('All Clear! 🎉',
                      style: GoogleFonts.inter(
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          color: isDark ? Colors.white : const Color(0xFF1A1A2E))),
                  const SizedBox(height: 4),
                  Text('No urgent tasks right now.',
                      style: GoogleFonts.inter(
                          fontSize: 13, color: Colors.grey[400])),
                ]),
          ),
        ]),
      );

  Widget _buildScheduleCard(ScheduleItem item, bool isDark) {
    final timeStr = DummyData.formatTimeOfDay(item.time);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF2A2A40) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 3)),
        ],
      ),
      child: Row(children: [
        Container(
          width: 52,
          height: 52,
          decoration: BoxDecoration(
              color: item.color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12)),
          child: Center(
            child: Text(timeStr,
                textAlign: TextAlign.center,
                style: GoogleFonts.inter(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: item.color,
                    height: 1.3)),
          ),
        ),
        const SizedBox(width: 12),
        Container(
            width: 3,
            height: 44,
            decoration: BoxDecoration(
                color: item.color,
                borderRadius: BorderRadius.circular(2))),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.title,
                    style: GoogleFonts.inter(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: isDark ? Colors.white : const Color(0xFF1A1A2E))),
                const SizedBox(height: 4),
                Row(children: [
                  Icon(Icons.location_on_outlined,
                      size: 13, color: Colors.grey[400]),
                  const SizedBox(width: 2),
                  Expanded(
                    child: Text(item.location,
                        style: GoogleFonts.inter(
                            fontSize: 12, color: Colors.grey[500]),
                        overflow: TextOverflow.ellipsis),
                  ),
                  Text('• ${item.durationMinutes} min',
                      style: GoogleFonts.inter(
                          fontSize: 12, color: Colors.grey[400])),
                ]),
              ]),
        ),
      ]),
    );
  }

  Widget _buildEmptySchedule(bool isDark) => Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 40),
        decoration: BoxDecoration(
            color: isDark ? const Color(0xFF2A2A40) : Colors.white,
            borderRadius: BorderRadius.circular(16)),
        child: Column(children: [
          Icon(Icons.event_available, size: 48, color: Colors.grey[500]),
          const SizedBox(height: 12),
          Text('No classes today!\nEnjoy your free day 🎉',
              textAlign: TextAlign.center,
              style:
                  GoogleFonts.inter(fontSize: 14, color: Colors.grey[400])),
        ]),
      );

  void _showAddTaskSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => TaskFormSheet(
        onSave: (task) => AppState.instance.addTask(task),
      ),
    );
  }
}
