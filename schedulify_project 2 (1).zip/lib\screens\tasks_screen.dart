import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/app_models.dart';
import '../state/app_state.dart';
import '../widgets/task_form_sheet.dart';
import 'notifications_screen.dart';

class TasksTab extends StatefulWidget {
  const TasksTab({super.key});

  @override
  State<TasksTab> createState() => _TasksTabState();
}

class _TasksTabState extends State<TasksTab>
    with SingleTickerProviderStateMixin {
  int _filterIndex = 0;
  late AnimationController _animController;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 400));
    _fadeAnim =
        CurvedAnimation(parent: _animController, curve: Curves.easeIn);
    _animController.forward();
    AppState.instance.addListener(_onStateChanged);
  }

  void _onStateChanged() => setState(() {});

  @override
  void dispose() {
    AppState.instance.removeListener(_onStateChanged);
    _animController.dispose();
    super.dispose();
  }

  List<Task> get _filteredTasks {
    final all = AppState.instance.tasks;
    switch (_filterIndex) {
      case 1:
        return all.where((t) => !t.isCompleted).toList();
      case 2:
        return all.where((t) => t.isCompleted).toList();
      default:
        return all.toList();
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = AppState.instance;
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final filtered = _filteredTasks;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddSheet(context),
        backgroundColor: const Color(0xFF3B5BDB),
        child: const Icon(Icons.add, color: Colors.white, size: 28),
      ),
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnim,
          child: CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [_buildAvatar(isDark), _buildNotifBell(isDark)],
                      ),
                      const SizedBox(height: 22),
                      Text('My Tasks',
                          style: GoogleFonts.inter(
                              fontSize: 30,
                              fontWeight: FontWeight.w800,
                              color: theme.textTheme.bodyLarge?.color)),
                      const SizedBox(height: 4),
                      Text(
                        'You have ${state.pendingCount} assignment${state.pendingCount == 1 ? '' : 's'} pending.',
                        style: GoogleFonts.inter(
                            fontSize: 13, color: Colors.grey[500]),
                      ),
                      const SizedBox(height: 20),
                      Row(children: [
                        _filterPill('All', 0, isDark),
                        const SizedBox(width: 10),
                        _filterPill('Pending', 1, isDark),
                        const SizedBox(width: 10),
                        _filterPill('Completed', 2, isDark),
                      ]),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
              if (filtered.isEmpty)
                SliverFillRemaining(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.inbox_outlined,
                            size: 56, color: Colors.grey[500]),
                        const SizedBox(height: 12),
                        Text('No tasks here!',
                            style: GoogleFonts.inter(
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                color: Colors.grey[400])),
                      ],
                    ),
                  ),
                )
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                  sliver: SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (context, i) => _buildTaskCard(filtered[i], isDark),
                      childCount: filtered.length,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _filterPill(String label, int index, bool isDark) {
    final isSelected = _filterIndex == index;
    return GestureDetector(
      onTap: () {
        setState(() => _filterIndex = index);
        _animController.forward(from: 0);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
        decoration: BoxDecoration(
          color: isSelected
              ? const Color(0xFF3B5BDB)
              : (isDark ? const Color(0xFF2A2A40) : Colors.white),
          borderRadius: BorderRadius.circular(30),
          boxShadow: [
            BoxShadow(
              color: isSelected
                  ? const Color(0xFF3B5BDB).withOpacity(0.3)
                  : Colors.black.withOpacity(0.04),
              blurRadius: 8,
              offset: const Offset(0, 3),
            )
          ],
        ),
        child: Text(label,
            style: GoogleFonts.inter(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: isSelected
                    ? Colors.white
                    : (isDark ? Colors.grey[400] : Colors.grey[500]))),
      ),
    );
  }

  Widget _buildTaskCard(Task task, bool isDark) {
    final statusColor = DummyData.getStatusColor(task.status);
    final statusBg = DummyData.getStatusBgColor(task.status);
    final statusLabel = DummyData.getStatusLabel(task.status);

    return Dismissible(
      key: Key(task.id),
      direction: DismissDirection.endToStart,
      background: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.only(right: 20),
        decoration: BoxDecoration(
          color: Colors.red,
          borderRadius: BorderRadius.circular(18),
        ),
        alignment: Alignment.centerRight,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.delete_outline, color: Colors.white, size: 26),
            const SizedBox(height: 4),
            Text('Delete',
                style: GoogleFonts.inter(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: Colors.white)),
          ],
        ),
      ),
      confirmDismiss: (_) async {
        return await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: isDark ? const Color(0xFF2A2A40) : Colors.white,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: Text('Delete Task',
                style: GoogleFonts.inter(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: isDark ? Colors.white : const Color(0xFF1A1A2E))),
            content: Text('Are you sure you want to delete "${task.title}"?',
                style:
                    GoogleFonts.inter(fontSize: 14, color: Colors.grey[500])),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: Text('Cancel',
                      style: GoogleFonts.inter(
                          fontWeight: FontWeight.w600,
                          color: Colors.grey[500]))),
              ElevatedButton(
                onPressed: () => Navigator.pop(ctx, true),
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12))),
                child: Text('Delete',
                    style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
              ),
            ],
          ),
        );
      },
      onDismissed: (_) => AppState.instance.deleteTask(task.id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF2A2A40) : Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 12,
                offset: const Offset(0, 4)),
          ],
        ),
        child: Row(children: [
          // Color bar
          Container(
            width: 5,
            height: 84,
            decoration: BoxDecoration(
              color: task.isCompleted ? Colors.grey[600] : statusColor,
              borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(18),
                  bottomLeft: Radius.circular(18)),
            ),
          ),
          const SizedBox(width: 14),
          // Checkbox
          GestureDetector(
            onTap: () => AppState.instance.toggleTask(task.id),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 22,
              height: 22,
              decoration: BoxDecoration(
                color: task.isCompleted ? statusColor : Colors.transparent,
                border: Border.all(
                    color: task.isCompleted
                        ? statusColor
                        : (isDark ? Colors.grey[600]! : Colors.grey[300]!),
                    width: 2),
                borderRadius: BorderRadius.circular(6),
              ),
              child: task.isCompleted
                  ? const Icon(Icons.check, size: 14, color: Colors.white)
                  : null,
            ),
          ),
          const SizedBox(width: 14),
          // Info
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(task.title,
                        style: GoogleFonts.inter(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: task.isCompleted
                                ? Colors.grey[500]
                                : (isDark ? Colors.white : const Color(0xFF1A1A2E)),
                            decoration: task.isCompleted
                                ? TextDecoration.lineThrough
                                : null)),
                    const SizedBox(height: 6),
                    Row(children: [
                      Icon(Icons.calendar_today_outlined,
                          size: 12, color: Colors.grey[500]),
                      const SizedBox(width: 4),
                      Text(DateFormat('MMM d').format(task.dueDate),
                          style: GoogleFonts.inter(
                              fontSize: 12, color: Colors.grey[500])),
                      const SizedBox(width: 10),
                      Icon(Icons.school_outlined,
                          size: 12, color: Colors.grey[500]),
                      const SizedBox(width: 4),
                      Text(task.category,
                          style: GoogleFonts.inter(
                              fontSize: 12, color: Colors.grey[500])),
                    ]),
                  ]),
            ),
          ),
          // Status badge + edit button
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                    color: task.isCompleted
                        ? (isDark ? Colors.grey[800] : Colors.grey[100])
                        : (isDark ? statusColor.withOpacity(0.2) : statusBg),
                    borderRadius: BorderRadius.circular(20)),
                child: Text(statusLabel,
                    style: GoogleFonts.inter(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: task.isCompleted
                            ? Colors.grey[500]
                            : statusColor,
                        letterSpacing: 0.4)),
              ),
              const SizedBox(height: 6),
              GestureDetector(
                onTap: () => _showEditSheet(context, task),
                child: Icon(Icons.edit_outlined,
                    size: 18, color: Colors.grey[500]),
              ),
            ],
          ),
          const SizedBox(width: 14),
        ]),
      ),
    );
  }

  Widget _buildAvatar(bool isDark) => Row(children: [
        Container(
          width: 44,
          height: 44,
          decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                  colors: [Color(0xFF3B5BDB), Color(0xFF74C0FC)])),
          child: const Icon(Icons.person, color: Colors.white, size: 24),
        ),
        const SizedBox(width: 12),
        Text('Hello, ${AppState.instance.currentUser?.name.split(' ').first ?? 'Friend'}!',
            style: GoogleFonts.inter(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: isDark ? Colors.white : const Color(0xFF1A1A2E))),
      ]);

  Widget _buildNotifBell(bool isDark) => GestureDetector(
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const NotificationsScreen())),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: isDark ? const Color(0xFF2A2A40) : Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  blurRadius: 8,
                  offset: const Offset(0, 2))
            ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              const Icon(Icons.notifications_outlined,
                  color: Color(0xFF3B5BDB), size: 22),
              if (AppState.instance.unreadNotificationCount > 0)
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                        color: Color(0xFFF03E3E), shape: BoxShape.circle),
                    constraints: const BoxConstraints(
                      minWidth: 12,
                      minHeight: 12,
                    ),
                  ),
                ),
            ],
          ),
        ),
      );

  void _showAddSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => TaskFormSheet(
        onSave: (task) => AppState.instance.addTask(task),
      ),
    );
  }

  void _showEditSheet(BuildContext context, Task task) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => TaskFormSheet(
        task: task,
        onSave: (updated) => AppState.instance.updateTask(updated),
      ),
    );
  }
}
