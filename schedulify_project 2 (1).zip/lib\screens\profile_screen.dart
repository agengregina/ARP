import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../state/app_state.dart';
import '../services/notification_service.dart';
import 'login_screen.dart';

class ProfileTab extends StatefulWidget {
  const ProfileTab({super.key});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  late TextEditingController _nameCtrl;
  late TextEditingController _emailCtrl;
  late TextEditingController _majorCtrl;
  late int _selectedSemester;
  bool _isEditing = false;

  @override
  void initState() {
    super.initState();
    final user = AppState.instance.currentUser;
    _nameCtrl = TextEditingController(text: user?.name ?? 'Guest User');
    _emailCtrl = TextEditingController(text: user?.email ?? 'guest@university.edu');
    _majorCtrl = TextEditingController(text: user?.major ?? 'Computer Science');
    _selectedSemester = user?.semester ?? 1;
    AppState.instance.addListener(_onStateChanged);
  }

  void _onStateChanged() => setState(() {});

  @override
  void dispose() {
    AppState.instance.removeListener(_onStateChanged);
    _nameCtrl.dispose();
    _emailCtrl.dispose();
    _majorCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppState.instance;
    final completed = state.completedCount;
    final total = state.totalCount;
    final progress = total == 0 ? 0.0 : completed / total;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // ── Gradient Header ──
              Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(20, 24, 20, 32),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF1A2980), Color(0xFF3B5BDB)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(36),
                    bottomRight: Radius.circular(36),
                  ),
                ),
                child: Column(children: [
                  Container(
                    width: 88,
                    height: 88,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.2),
                      border: Border.all(
                          color: Colors.white.withOpacity(0.5), width: 2.5),
                      boxShadow: [
                        BoxShadow(
                            color: Colors.black.withOpacity(0.2),
                            blurRadius: 20,
                            offset: const Offset(0, 8))
                      ],
                    ),
                    child:
                        const Icon(Icons.person, color: Colors.white, size: 48),
                  ),
                  const SizedBox(height: 16),
                  _isEditing
                      ? Column(children: [
                          _editField(_nameCtrl, 'Full Name'),
                          const SizedBox(height: 8),
                          _editField(_emailCtrl, 'Email'),
                          const SizedBox(height: 8),
                          _editField(_majorCtrl, 'Major / Course'),
                          const SizedBox(height: 12),
                          _editSemesterSelector(),
                          const SizedBox(height: 12),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                TextButton(
                                  onPressed: () =>
                                      setState(() => _isEditing = false),
                                  child: Text('Cancel',
                                      style: GoogleFonts.inter(
                                          color: Colors.white.withOpacity(0.7),
                                          fontWeight: FontWeight.w600)),
                                ),
                                const SizedBox(width: 12),
                                ElevatedButton(
                                  onPressed: () async {
                                    await AppState.instance.updateCurrentUser(
                                      name: _nameCtrl.text,
                                      email: _emailCtrl.text,
                                      major: _majorCtrl.text,
                                      semester: _selectedSemester,
                                    );
                                    setState(() => _isEditing = false);
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text('Profile updated!',
                                            style: GoogleFonts.inter(
                                                fontWeight: FontWeight.w600)),
                                        backgroundColor: const Color(0xFF3B5BDB),
                                        behavior: SnackBarBehavior.floating,
                                      ),
                                    );
                                  },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.white,
                                    foregroundColor:
                                        const Color(0xFF3B5BDB),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(20)),
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 20, vertical: 8),
                                  ),
                                  child: Text('Save',
                                      style: GoogleFonts.inter(
                                          fontWeight: FontWeight.w700)),
                                ),
                              ]),
                        ])
                      : Column(children: [
                          Text(_nameCtrl.text,
                              style: GoogleFonts.inter(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  color: Colors.white)),
                          const SizedBox(height: 4),
                          Text(_emailCtrl.text,
                              style: GoogleFonts.inter(
                                  fontSize: 13,
                                  color: Colors.white.withOpacity(0.75))),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                                '🎓  ${state.currentUser?.major ?? "Computer Science"} • Semester ${state.currentUser?.semester ?? 1}',
                                style: GoogleFonts.inter(
                                    fontSize: 12,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600)),
                          ),
                        ]),
                ]),
              ),
              const SizedBox(height: 24),

              // ── Stats Row ──
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(children: [
                  _statCard('$completed', 'Completed',
                      Icons.check_circle_outline, const Color(0xFF2F9E44)),
                  const SizedBox(width: 12),
                  _statCard('${state.pendingCount}', 'Pending',
                      Icons.pending_outlined, const Color(0xFFE67700)),
                  const SizedBox(width: 12),
                  _statCard('$total', 'Total Tasks',
                      Icons.task_alt_outlined, const Color(0xFF3B5BDB)),
                ]),
              ),
              const SizedBox(height: 20),

              // ── Progress Card ──
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 12,
                          offset: const Offset(0, 4))
                    ],
                  ),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                            mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                            children: [
                              Text('Weekly Progress',
                                  style: GoogleFonts.inter(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w700,
                                      color: Theme.of(context).textTheme.bodyLarge?.color)),
                              Text('${(progress * 100).toInt()}%',
                                  style: GoogleFonts.inter(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w700,
                                      color: const Color(0xFF3B5BDB))),
                            ]),
                        const SizedBox(height: 12),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: TweenAnimationBuilder<double>(
                            tween: Tween(begin: 0, end: progress),
                            duration: const Duration(milliseconds: 800),
                            curve: Curves.easeOut,
                            builder: (_, value, __) =>
                                LinearProgressIndicator(
                              value: value,
                              minHeight: 10,
                              backgroundColor: const Color(0xFFE8EDFF),
                              valueColor:
                                  const AlwaysStoppedAnimation<Color>(
                                      Color(0xFF3B5BDB)),
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                        Text(
                            '$completed of $total tasks completed',
                            style: GoogleFonts.inter(
                                fontSize: 12, color: Colors.grey[400])),
                      ]),
                ),
              ),
              const SizedBox(height: 20),

              // ── Settings Menu ──
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).cardColor,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 12,
                          offset: const Offset(0, 4))
                    ],
                  ),
                  child: Column(children: [
                    _menuItem(Icons.person_outline, 'Edit Profile',
                        const Color(0xFF3B5BDB),
                        onTap: () =>
                            setState(() => _isEditing = !_isEditing)),
                    _divider(),
                    _menuItem(Icons.notifications_outlined, 'Notifications',
                        const Color(0xFF7048E8),
                        onTap: () => _showNotificationSettings(context)),
                    _divider(),
                    _menuItem(Icons.palette_outlined, 'Appearance',
                        const Color(0xFF2F9E44),
                        onTap: () => _showThemeSettings(context)),
                    _divider(),
                    _menuItem(Icons.lock_outline, 'Privacy & Security',
                        const Color(0xFFE67700),
                        onTap: () => _showPrivacySettings(context)),
                    _divider(),
                    _menuItem(Icons.help_outline, 'Help & Support',
                        const Color(0xFF3B5BDB),
                        onTap: () => _showHelpSettings(context)),
                    _divider(),
                    _menuItem(Icons.logout_rounded, 'Sign Out', Colors.red,
                        onTap: () => _showLogoutDialog(context)),
                  ]),
                ),
              ),
              const SizedBox(height: 32),
              Text('Schedulify v1.0.0',
                  style:
                      GoogleFonts.inter(fontSize: 12, color: Colors.grey[400])),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _editField(TextEditingController ctrl, String label) => Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12)),
        child: TextField(
          controller: ctrl,
          style: GoogleFonts.inter(color: Colors.white, fontSize: 14),
          decoration: InputDecoration(
            labelText: label,
            labelStyle:
                GoogleFonts.inter(color: Colors.white.withOpacity(0.7)),
            border: InputBorder.none,
          ),
        ),
      );

  Widget _editSemesterSelector() => Container(
        margin: const EdgeInsets.symmetric(horizontal: 20),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.2),
            borderRadius: BorderRadius.circular(12)),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<int>(
            value: _selectedSemester,
            isExpanded: true,
            dropdownColor: const Color(0xFF1A2980),
            icon: const Icon(Icons.expand_more_rounded, color: Colors.white),
            style: GoogleFonts.inter(fontSize: 14, color: Colors.white),
            items: List.generate(8, (i) => i + 1)
                .map((s) => DropdownMenuItem(
                      value: s,
                      child: Text('Semester $s'),
                    ))
                .toList(),
            onChanged: (v) => setState(() => _selectedSemester = v!),
          ),
        ),
      );

  Widget _divider() => Divider(
      height: 1, indent: 72, endIndent: 20, color: Theme.of(context).dividerColor.withOpacity(0.1));

  void _showNotificationSettings(BuildContext context) {
    final isDark = AppState.instance.isDarkMode;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: isDark ? const Color(0xFF2A2A40) : Colors.white,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Notifications',
                style: GoogleFonts.inter(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: isDark ? Colors.white : const Color(0xFF1A1A2E))),
            const SizedBox(height: 20),
            SwitchListTile(
              title: Text('Push Notifications',
                  style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
              subtitle: Text('Receive reminders for upcoming tasks',
                  style: GoogleFonts.inter(fontSize: 12)),
              value: NotificationService.instance.enabled,
              activeColor: const Color(0xFF3B5BDB),
              onChanged: (v) {
                setState(() => NotificationService.instance.enabled = v);
                Navigator.pop(ctx);
              },
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.flash_on, color: Colors.amber),
              title: Text('Test Reminder',
                  style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
              onTap: () {
                Navigator.pop(ctx);
                NotificationService.instance.showDemo(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showThemeSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Appearance',
                style: GoogleFonts.inter(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: Theme.of(context).textTheme.bodyLarge?.color)),
            const SizedBox(height: 20),
            SwitchListTile(
              title: Text('Dark Mode',
                  style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
              subtitle: Text('Switch to a dark theme for lower eye strain',
                  style: GoogleFonts.inter(fontSize: 12)),
              value: AppState.instance.isDarkMode,
              activeColor: const Color(0xFF3B5BDB),
              onChanged: (v) {
                AppState.instance.toggleDarkMode();
                Navigator.pop(ctx);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showPrivacySettings(BuildContext context) {
    final oldPass = TextEditingController();
    final newPass = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Change Password',
            style: GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.w700)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: oldPass,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'Old Password'),
            ),
            TextField(
              controller: newPass,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'New Password'),
            ),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              final success = await AppState.instance
                  .changePassword(oldPass.text, newPass.text);
              if (ctx.mounted) Navigator.pop(ctx);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(success
                        ? 'Password updated successfully!'
                        : 'Incorrect old password.'),
                    backgroundColor: success ? Colors.green : Colors.red,
                    behavior: SnackBarBehavior.floating,
                  ),
                );
              }
            },
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }

  void _showHelpSettings(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Help & Support',
                style: GoogleFonts.inter(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: Theme.of(context).textTheme.bodyLarge?.color)),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.info_outline, color: Color(0xFF3B5BDB)),
              title: const Text('About Schedulify'),
              subtitle: const Text('Version 1.0.0\nSchedulify is an academic productivity app built to help students manage their tasks, classes, and deadlines in one seamless and responsive interface. Designed with simplicity and efficiency in mind.'),
              isThreeLine: true,
            ),
            ListTile(
              leading: const Icon(Icons.menu_book_rounded, color: Color(0xFF2F9E44)),
              title: const Text('App Guide'),
              subtitle: const Text('• Home: View daily schedule and nearest priority task.\n• Tasks: Manage assignments and to-dos.\n• Schedule: Organize weekly/monthly classes.\n• Profile: Customize app theme and settings.'),
              isThreeLine: true,
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _statCard(String value, String label, IconData icon, Color color) =>
      Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 16),
          decoration: BoxDecoration(
            color: Theme.of(context).cardColor,
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 3))
            ],
          ),
          child: Column(children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.12), shape: BoxShape.circle),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(height: 8),
            Text(value,
                style: GoogleFonts.inter(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Theme.of(context).textTheme.bodyLarge?.color)),
            const SizedBox(height: 2),
            Text(label,
                style: GoogleFonts.inter(
                    fontSize: 11, color: Colors.grey[400]),
                textAlign: TextAlign.center),
          ]),
        ),
      );

  Widget _menuItem(IconData icon, String label, Color color,
          {VoidCallback? onTap}) =>
      InkWell(
        onTap: onTap ?? () {},
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Row(children: [
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 18),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(label,
                  style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: label == 'Sign Out'
                          ? Colors.red
                          : Theme.of(context).textTheme.bodyLarge?.color)),
            ),
            Icon(Icons.chevron_right, color: Colors.grey[300], size: 20),
          ]),
        ),
      );

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Sign Out',
            style: GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.w700)),
        content: Text('Are you sure you want to sign out?',
            style: GoogleFonts.inter(fontSize: 14, color: Colors.grey[500])),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text('Cancel',
                  style: GoogleFonts.inter(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: Colors.grey[500]))),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await AppState.instance.logout();
              if (context.mounted) {
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(builder: (_) => const LoginScreen()),
                    (route) => false);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12))),
            child: Text('Sign Out',
                style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
          ),
        ],
      ),
    );
  }
}
